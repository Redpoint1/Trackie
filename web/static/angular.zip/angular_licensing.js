"use strict";

(function () {
	
	var licensing_module = angular.module('licensing', ['user_priviliged', 'user_common', 'naif.base64']);

	licensing_module.run((['api_directory', '$rootScope', '$route'],function(api_directory, $rootScope, $route){
		api_directory.then(function (api_directory) {
			$globalRouteProvider
			.when('/organization',{ 
				templateUrl: api_directory.get_endpoint_partial('licensing_restV1_OrganizationAPIView'),
				controller : 'OrganizationCtrl'                                                        ,
			})
			.when('/suborganizations',{
                template   : 'Loading...'                 ,
                controller : 'RedirectSubOrganizationCtrl',
            })
			.when('/suborganizations/new',{
                templateUrl: api_directory.get_endpoint_partial('licensing_restV1_SubOrganizationAPIView'),
                controller : 'NewSubOrganizationCtrl'                                                     ,
            })
			.when('/suborganizations/:suborg_id',{ 
                templateUrl: api_directory.get_endpoint_partial('licensing_restV1_SubOrganizationDetailAPIView'),
                controller : 'SubOrganizationCtrl'                                                              ,
            })
			.when('/shop',{ 
				templateUrl: api_directory.get_endpoint_partial('licensing_restV1_ShopAPIView')
			})
			.when('/shop/product/:product_id',{ 
                templateUrl: api_directory.get_endpoint_partial('licensing_restV1_ProductOverviewAPIView'),
                controller : "ShopProductOverview"
            })
			.when('/shop/purchase/product/:product_id/duration/:duration_amount',{ 
				templateUrl: api_directory.get_endpoint_partial('licensing_restV1_PurchaseAPIListView', 'payment'),
				controller : 'PurchasingCtrl'                                                                     ,
			})
			.when('/shop/purchase/product/:product_id/duration/:duration_amount/payment/:payment_method',{ 
				templateUrl: api_directory.get_endpoint_partial('licensing_restV1_PurchaseAPIListView', 'overview'),
				controller : 'PurchasingCtrl'                                                                      ,
			});
			
			$route.reload();
		});
	}));
	
	//------------------------------------------------------------------------------
	
	
	licensing_module
	.directive('shopProducts', (['Product', 'api_directory', '$http', '$templateCache', '$compile', '$location'], function(Product, api_directory, $http, $templateCache, $compile, $location){
		
		var gettext = (window.django && window.django.gettext) || function (msg){return msg;};
		
		var productResourceObject = new Product();
				
		var htmlBinder = function (scope, element, attrs){
			scope.data  = {};

			/* Init scope */
			
			scope.products = {
				objs : undefined,
			};
			scope.error = gettext('No results.')
			
			scope.overview = function(id){
                $location.url('/shop/product/'+id);
            }
			
			/* Retrieve the template */
			api_directory.then(function (api_directory){
				var partial_url = api_directory
					.get_endpoint_partial('licensing_restV1_ActiveProductListAPIView')
				;
				
				var templateLoader = $http.get(partial_url, {cache: $templateCache});
				templateLoader.success(function (html) {
					//scope._template = html;
					var contentElem = angular.element(html);
					$compile(contentElem)(scope);
					
					element.append(contentElem)
				});
			});
			
			/* Get the data and put it in scope */
			
			productResourceObject.query().then(
			    function (products){
			    	scope.products = products;
			    },
			    function (error_message){
			    	scope.error = error_message.detail; 
			    }
			);
		};
		
		return {
			link    : htmlBinder,
			restrict: 'A'       ,
			/* Make scope available to the controller */
			scope   : false
		};
		
	}));
	
	//------------------------------------------------------------------------------
        
    licensing_module
	.factory('Organization', (['APIResourceObject'], function (APIResourceObject){
		
		function Organization(manager_id){
			
			APIResourceObject.call(
				this,
				
			    null                                  ,
			    'licensing_restV1_OrganizationAPIView',
			    {'manager': manager_id}               ,
			    {}
			)
		}
		
		Organization.prototype = Object.create(APIResourceObject.prototype);
		Organization.prototype.constructor = Organization;
		
		Organization.prototype.prepare_data = function (data){
			var dataset = APIResourceObject.prototype.prepare_data.call(this, data);
			
			if (this.logo_remove)
				dataset.logo_remove = true;
			
			if (this.logo_new)
				dataset.logo = this.logo_new;
			else
				// Prevent logo url retrieved from server
				// to be sent
				delete dataset.logo; 
			return dataset;
		}
		Organization.prototype.restore_data = function (data){
			APIResourceObject.prototype.restore_data.call(this, data);
			this.logo_remove = false;
		}
		
		return Organization;
	}));
	
	licensing_module
	.factory('Product', (['APIResourceObject'], function (APIResourceObject){
		
		function Product(){
			
			APIResourceObject.call(
				this,
				
			    'licensing_restV1_ActiveProductListAPIView',
			    null                                       ,
			    {}                                         ,
			    {}
			)
		}
		
		Product.prototype = Object.create(APIResourceObject.prototype);
		Product.prototype.constructor = Product;
		
		return Product;
	}));
	
   licensing_module
    .factory('ProductOverview', (['APIResourceObject', '$routeParams'], function (APIResourceObject, $routeParams){
        
        function ProductOverview(){
            
            APIResourceObject.call(
                this,
                
                null                                     ,
                'licensing_restV1_ProductOverviewAPIView',
                {"id": $routeParams.product_id}          ,
                {}
            )
        }
        
        ProductOverview.prototype = Object.create(APIResourceObject.prototype);
        ProductOverview.prototype.constructor = ProductOverview;
        
        return ProductOverview;
    }));
	
	licensing_module
	.factory('logged_in_user_organization', (['$cookies', 'UserNotLoggedInException', 'Organization'], function ($cookies, UserNotLoggedInException, Organization){
		
		var manager_id = $cookies.user_id;
		
		if (!manager_id)
			throw new UserNotLoggedInException('cannot retrieve logged in user organization');
		
		return new Organization(manager_id);
		
	}));
	
	//------------------------------------------------------------------------------
	
   licensing_module
    .factory('SubOrganization', (['APIResourceObject'], function (APIResourceObject) {
        
        function SubOrganization(user_id, suborg_id) {
            APIResourceObject.call(
                this,
                
                'licensing_restV1_SubOrganizationAPIView'      ,
                'licensing_restV1_SubOrganizationDetailAPIView',
                {'manager': user_id, 'suborganization': suborg_id},
                {}
            )
        }
        
        SubOrganization.prototype = Object.create(APIResourceObject.prototype);
        SubOrganization.prototype.constructor = SubOrganization;
        
        SubOrganization.prototype.prepare_data = function (data){
            var dataset = APIResourceObject.prototype.prepare_data.call(this, data);
            
            if (this.logo_remove)
                dataset.logo_remove = true;
            
            if (this.logo_new)
                dataset.logo = this.logo_new;
            else
                // Prevent logo url retrieved from server
                // to be sent
                delete dataset.logo; 
            return dataset;
        }
        SubOrganization.prototype.restore_data = function (data){
            APIResourceObject.prototype.restore_data.call(this, data);
            this.logo_remove = false;
        }
        
        return SubOrganization;
    }));
   
   licensing_module
   .factory('LoggedInSuborganization', (['$cookies', 'UserNotLoggedInException', 'SubOrganization'], function ($cookies, UserNotLoggedInException, SubOrganization){
       
       function LoggedInSuborganization(suborg_id) {
           var user_id = $cookies.user_id;
           
           if (!user_id)
               throw new UserNotLoggedInException('cannot retrieve logged in user suborganizations');
           else
               SubOrganization.call(this, user_id, suborg_id);
       }
       
       LoggedInSuborganization.prototype = Object.create(SubOrganization.prototype);
       LoggedInSuborganization.prototype.constructor = LoggedInSuborganization;
       
       return LoggedInSuborganization;
       
   }));
   
   licensing_module
   .service('suborganization_menu_service', (['$rootScope', '$location', 'LoggedInOrganizationFeature', 'LoggedInSuborganization'], function($rootScope, $location, LoggedInOrganizationFeature, LoggedInSuborganization) {
        var self = this;

        $rootScope.$watch(
            function() {
                return $location.path();
            },
            function(value) {
                if(value.indexOf('suborganizations') == -1) {
                    self.clean_rootscope();
                }
            }
        );

        this.init = function(suborganization_id) {
            self.init_rootscope();
            if(self.suborganizations.length == 0) {
                self.retrieve_suborganizations(suborganization_id);
            }
            else {
                self.update_or_get_suborganizations(suborganization_id);
            }
            if(self.organization_features.length == 0) {
                self.retrieve_organization_features();
            }
        }

        this.init_rootscope = function() {
            $rootScope.is_suborganization = true;
            if(!$rootScope.menu_service) {
                $rootScope.menu_service = self;
            }
        }

        this.clean_rootscope = function() {
            delete $rootScope.is_suborganization;
        }

        this.go_to_feature = function(path) {
            $location.search("page", null);
            var edit_url = '/suborganizations/' + self.current_suborganization.id;
            $location.path(edit_url + path);
        }

        this.organization_features = [];
        this.organizationFeatureResourceObject = new LoggedInOrganizationFeature();
        this.retrieve_organization_features = function() {
            self.organizationFeatureResourceObject.query().then(
                function(features) {
                    self.organization_features = features.objs;
                }
            )
        }

        this.organization_has_feature = function(name) {
            for(var organization_feature in self.organization_features) {
                if(self.organization_features[organization_feature].verbose_name == name) {
                    return true;
                }
            }
            return false;
        }

        this.specific_suborganization = false;
        this.current_suborganization = {};
        this.set_current_suborganization = function(suborganization_id) {
            if(suborganization_id) {
                self.specific_suborganization = true;
                self.current_suborganization = self.get_suborganization(suborganization_id);
            }
            else {
                if($location.path().indexOf('new') == -1 && self.suborganizations.length > 1) {
                    self.specific_suborganization = true;
                    self.current_suborganization = self.suborganizations[1];
                    self.change_selected_suborganization();
                }
                else {
                    self.specific_suborganization = false;
                    self.current_suborganization = self.suborganizations[0];
                }
            }
        }

        this.change_selected_suborganization = function() {
            if(self.current_suborganization.id == 0) {
                self.specific_suborganization = false;
                $location.search("page", null);
                $location.path('/suborganizations/new');
            }
            else {
                self.specific_suborganization = true;
                $location.search("page", null);
                var edit_url = '/suborganizations/' + self.current_suborganization.id;
                if($location.path().length > edit_url.length && $location.path().indexOf('new') == -1) {
                    var feature_url = $location.path().substring(edit_url.length);
                    $location.path(edit_url + feature_url);
                }
                else {
                    $location.path(edit_url);
                }
            }
        }
        this.edit_selected_suborganization = function() {
            $location.search("page", null);
            $location.path('/suborganizations/' + self.current_suborganization.id);
        }
        this.update_or_get_suborganizations = function(id) {
            if(id == null || id == 0 || self.get_suborganization(id)) {
                self.set_current_suborganization(id);
            }
            else {
                self.retrieve_suborganizations(id);
            }
        }

        this.suborganizations = [];
        this.suborganizationsResourceObject = new LoggedInSuborganization();
        this.get_suborganization = function(id) {
            for(var suborganization in self.suborganizations) {
                if(self.suborganizations[suborganization].id == id) {
                    return self.suborganizations[suborganization];
                }
            }
            return null;
        }
        this.retrieve_suborganizations = function(suborganization_id) {
            self.suborganizationsResourceObject.query().then(
                function (suborgs) {
                    self.suborganizations = suborgs.objs;
                    self.suborganizations.unshift({id: 0, social_denomination: 'Create new', logo: null});
                    self.set_current_suborganization(suborganization_id);
                }
            );
        }
   }));

	//------------------------------------------------------------------------------
	
	licensing_module
	.factory('Purchases', (['APIResourceObject'], function (APIResourceObject) {
		
		function Purchases(user_id) {
			APIResourceObject.call(
				this,
				
				'licensing_restV1_PurchaseAPIListView',
				null                                  ,
				{'pk': user_id}                       ,
				{}
			)
		}
		
		Purchases.prototype = Object.create(APIResourceObject.prototype);
		Purchases.prototype.constructor = Purchases;
		
		return Purchases;
	}));
	
	licensing_module
    .factory('logged_in_user_purchases', (['$cookies', 'UserNotLoggedInException', 'Purchases'], function ($cookies, UserNotLoggedInException, Purchases){
        
        var user_id = $cookies.user_id;
        
        if (!user_id)
            throw new UserNotLoggedInException('cannot retrieve logged in user purchases');
        
        return new Purchases(user_id);
        
    }));
	
	licensing_module
	.service('purchasing_service', (['$location', '$routeParams', 'logged_in_user_purchases', 'flash_message_service'], function($location, $routeParams, logged_in_user_purchases, flash_message_service) {
		
		var self = this;
		
		this.purchases = logged_in_user_purchases;
		this.last_action = null;
		this.dataset = {
			product: $routeParams.product_id,
			duration: $routeParams.duration_amount,
			payment_method: 0
		}
        
        this.last_error_message = {
            	detail        : null,
            	named_details : null,
        }
            
        this.last_success_message = {
            	detail        : null,
            	named_details : null,
        }
		
		this.update = function(caller) {
			self.last_action = caller;
			self.dataset.product = $routeParams.product_id;
			self.dataset.duration = $routeParams.duration_amount;
		}
		
		this.select_payment = function() {
			self.update(self.select_payment);
			return $location.path('/shop/purchase/product/' + self.dataset.product + '/duration/' + self.dataset.duration); 
		}
		
		this.show_details = function() {
			self.update(self.show_details);
			return $location.path($location.url() + '/payment/' + self.dataset.payment_method);
		}
		
		this.cancel = function() {
			return $location.path('/shop');
		}
		
		this.check_progress = function() {
			if(self.dataset.product != null && self.dataset.duration != null) {
				if(self.last_action == null) {
					self.select_payment();
				}
				else {
					self.last_action();
				}
			}
		}
		
        function successPurchaseCallback(){
        	$location.path('/shop');
        }
        
        function failPurchaseCallback(error_message){
        	if(error_message.detail.indexOf('permission') > -1) {
				flash_message_service.message = error_message;
				$location.path('/organization');
        	}
        	else {
            	self.last_error_message.detail        = error_message.detail       ;
            	self.last_error_message.named_details = error_message.named_details;
        	}
        }
        
        this.buy = function (){
        	self.last_action = self.buy;
        	self.purchases.create(self.dataset).then(
    			successPurchaseCallback,
    			failPurchaseCallback   
        	);
        }
	}));
	
	//------------------------------------------------------------------------------

	licensing_module
	.factory('Feature', (['APIResourceObject'], function (APIResourceObject) {
		
		function Feature() {
			APIResourceObject.call(
				this,
				
				'licensing_restV1_FeatureAPIListView',
				null,
				{},
				{}
			)
		}
		
		Feature.prototype = Object.create(APIResourceObject.prototype);
		Feature.prototype.constructor = Feature;
		
		return Feature;
	}));

	licensing_module
	.factory('OrganizationFeature', (['APIResourceObject'], function(APIResourceObject) {

	    function OrganizationFeature(manager_id) {
	        APIResourceObject.call(
	            this,

	            'licensing_restV1_OrganizationFeatureAPIListView',
	            null,
	            {'manager': manager_id},
	            {}
	        )
	    }

	    OrganizationFeature.prototype = Object.create(APIResourceObject.prototype);
	    OrganizationFeature.prototype.constructor = OrganizationFeature;

	    return OrganizationFeature;
	}));

	licensing_module
	.factory('LoggedInOrganizationFeature', (['$cookies', 'UserNotLoggedInException', 'OrganizationFeature'], function ($cookies, UserNotLoggedInException, OrganizationFeature){

        function LoggedInOrganizationFeature() {
           var user_id = $cookies.user_id;

           if (!user_id)
               throw new UserNotLoggedInException('cannot retrieve logged in user organization features');
           else
               OrganizationFeature.call(this, user_id);
        }

        LoggedInOrganizationFeature.prototype = Object.create(OrganizationFeature.prototype);
        LoggedInOrganizationFeature.prototype.constructor = LoggedInOrganizationFeature;

        return LoggedInOrganizationFeature;

	}));
	
	//------------------------------------------------------------------------------
	
	licensing_module
    .controller('OrganizationCtrl', (['$scope', '$timeout', 'logged_in_user_organization', 'flash_message_service', 'purchasing_service'], function ($scope, $timeout, logged_in_user_organization, flash_message_service, purchasing_service){
        logged_in_user_organization.read();
        
        $scope.organization    = logged_in_user_organization                     ;
        $scope.error_message   = logged_in_user_organization.last_error_message  ;
        $scope.success_message = logged_in_user_organization.last_success_message;
        $scope.flash_message = flash_message_service.message;
        $scope.on_update_successfull = function (){
            if(flash_message_service.message) {
                if(flash_message_service.message.detail.indexOf('permission') > -1) {
                    $timeout(purchasing_service.check_progress, 3000);
                }
            }
            flash_message_service.message = null;
            $scope.flash_message = flash_message_service.message;
        };
        
    }));
	
	licensing_module
    .controller('ShopProductOverview', (['$scope', '$location', 'ProductOverview'], function ($scope, $location, ProductOverview){
        
        $scope.buy = function(id, duration){
            $location.url('/shop/purchase/product/'+id+'/duration/'+duration);
        }
        
        $scope.back = function(){
            $location.url('/shop');
        }
        
        var productOverviewResourceObject = new ProductOverview();

        productOverviewResourceObject.read().then(
            function (product){
                $scope.product = product;
                $scope.error   = undefined;
            },
            function (error_message){
                $scope.product = undefined;
                $scope.error   = error_message.detail; 
            }
        );
    }));
	
	licensing_module
	.controller('PurchasingCtrl', (['$scope', 'purchasing_service'], function ($scope, purchasing_service){
		$scope.purchasing_service = purchasing_service                     ;
		$scope.error_message      = purchasing_service.last_error_message  ;
		$scope.success_message    = purchasing_service.last_success_message;
	}));

	licensing_module
	.controller('RedirectSubOrganizationCtrl', (['suborganization_menu_service'], function(suborganization_menu_service) {
	    suborganization_menu_service.init();
	}));

	licensing_module
	.controller('NewSubOrganizationCtrl', (['$scope', '$location', 'LoggedInSuborganization', 'suborganization_menu_service'], function($scope, $location, LoggedInSuborganization, suborganization_menu_service) {
	    suborganization_menu_service.init();
	    
	    var logged_in_user_suborganization = new LoggedInSuborganization();
        
        $scope.suborganization = logged_in_user_suborganization                     ;
        $scope.error_message   = logged_in_user_suborganization.last_error_message  ;
        $scope.success_message = logged_in_user_suborganization.last_success_message;
        
        $scope.redirect_on_suborg = function(){
            $location.url('/suborganizations/'+$scope.suborganization.data.id);
        }
	}));
	
	licensing_module
    .controller('SubOrganizationCtrl', (['$scope', '$routeParams', 'LoggedInSuborganization', 'suborganization_menu_service'], function ($scope, $routeParams, LoggedInSuborganization, suborganization_menu_service){
        suborganization_menu_service.init($routeParams.suborg_id);
        var logged_in_user_suborganization = new LoggedInSuborganization($routeParams.suborg_id);
        
        logged_in_user_suborganization.read();
        
        $scope.suborganization = logged_in_user_suborganization                     ;
        $scope.error_message   = logged_in_user_suborganization.last_error_message  ;
        $scope.success_message = logged_in_user_suborganization.last_success_message;

        $scope.on_update_successfull = function() {
            suborganization_menu_service.retrieve_suborganizations($routeParams.suborg_id);
        }
    }));
	
})();
