"use strict";

(function () {
	
	var common_module = angular.module('user_common', ['api', 'ngSanitize', 'ngCookies', 'ngResource']);
	
	common_module.config(['$httpProvider', function($httpProvider) {
	    $httpProvider.defaults.xsrfCookieName = 'csrftoken';
	    $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
	}]);
	
	common_module
	.factory('UserInformation', (['APIResourceObject'], function (APIResourceObject) {
		
		function UserInformation(user_id){
			
			APIResourceObject.call(
			    this,
			    
			    'profile_restV1_UserAPIListView',
	            'profile_restV1_UserAPIView'    ,
	            {pk: user_id}
			)
		}
		
		UserInformation.prototype = Object.create(APIResourceObject.prototype);
		UserInformation.prototype.constructor = UserInformation;
		
		return UserInformation;
		
	}));
	
	common_module
	.factory('UserNotLoggedInException', function (){
		
		function UserNotLoggedInException(message){
			this.message = message;
		}
		
		UserNotLoggedInException.prototype.toString = function () {
			var str = django.gettext('The user is not logged in');
			
			if (this.message)
				str += ': ' + this.message
			
			str += '.';
			
			return str;
		}
		
		return UserNotLoggedInException;
	});

	common_module
	.factory('CurrentUserInformation', 
	(
		['UserInformation', '$cookies', 'api_directory', '$window', 'UserNotLoggedInException', 'APIResourceObject'], 
		function (UserInformation, $cookies, $http, api_directory, $window, UserNotLoggedInException, APIResourceObject)
	{
		
		function CurrentUserInformation(){
			var session_user_id = $cookies.user_id;
			
			if (!session_user_id)
				throw new UserNotLoggedInException('User ID not found in session.');
		
			UserInformation.call(this, session_user_id);	
		}
		
		CurrentUserInformation.prototype = Object.create(UserInformation.prototype);
		CurrentUserInformation.prototype.constructor = CurrentUserInformation;
		
		CurrentUserInformation.prototype.prepare_data = function (data){
			var dataset = APIResourceObject.prototype.prepare_data.call(this, data);
			
			if (this.phone_number == '')
				dataset.phone_number = undefined;
			
			return dataset;
		}
		
		CurrentUserInformation.prototype.logout = function (){
			var self = this;
			
			api_directory.then(function (api_directory){
				var logout_url = api_directory.get_endpoint_url('profile_restV1_LogoutAPIView');
				
				$http.post(logout_url)
				.success(function (message){
					self.last_error_message.named_details   = null;
					self.last_error_message.detail          = null;
					self.last_success_message.named_details = null;
					self.last_success_message.detail        = gettext('Successfully logged out, redirecting to the login page...');
					
					$cookies.user_id = null;
					$window.location.reload();
				})
				.error(function (message){
					self.last_success_message.named_details = null;
					self.last_success_message.detail        = null;
					self.last_error_message.named_details   = null;
					self.last_error_message.detail          = gettext('Log out error, please contact staff.');
				});
			});	
		}
		
		return CurrentUserInformation;
	}));

})();