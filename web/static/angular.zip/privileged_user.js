"use strict";

$( document ).ready(function() {
	var urlHash = window.location.hash;
	urlHash = urlHash.charAt(urlHash.length - 1) == "/" ? urlHash : urlHash+"/";
	
	/* Header functionality */
	$('#app-header>ul>li>a').each(function( index ) {
		if ( urlHash.indexOf(this.hash) != -1) {
			$(this).parent().addClass('selected');
			return false;
		}
	});
	
	$('body').on('click', function (e) {
		$('#header-requests > ul:first').removeClass('selected');
		$('#app-header>ul').removeClass('open');
		$('#suborg-menu').removeClass('show');
	});
	
	$('#header-requests').on('click', function (e) {
		$(this).children("ul:first").toggleClass('selected');
		e.stopPropagation();
	});
	
	$('#header-requests>ul>:first-child').on('click', function (e) {
		e.stopPropagation();
	});
	
	$('#header-requests>ul>li').on('click', function (e) {
		e.stopPropagation();
		$(this).removeClass('new');
	});
	
	$('#menu-button').on('click', function (e) {
		$('#app-header>ul').toggleClass('open');
		e.stopPropagation();
		
	});
	
	$('#app-header>ul>li').on('click', function (e) {
		$('#app-header>ul>li').removeClass('selected');
		$(this).addClass('selected');
		$('#app-header>ul').removeClass('open');
		e.stopPropagation();
	});
	
	$('#app-header>ul>li>a').on('click', function (e) {
		if ( $(this).parent().hasClass('selected') ) {
			e.preventDefault();
		}
	});
	
});