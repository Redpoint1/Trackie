'use strict';

(function () {
	
	var agr_module = angular.module(
		'agr', 
		[
		 	'api'            ,
		 	'user_priviliged', 
		 	'licensing'      , 
		]
	);
	
	agr_module.run((['api_directory', '$rootScope', '$route'],function(api_directory, $rootScope, $route){
		
		api_directory.then(function (api_directory) {
			
			$globalRouteProvider
			
			// User-State Redirector
			.when('/',{ 
				controller : 'RedirectRootController',
				template   : 'loading...'
			})
			
			// Farm list
			.when('/suborganizations/:suborg_id/farms/', {
                controller : 'FarmListController'                                          ,
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_farm_list')
            })
            
            // Farm detail
			.when('/suborganizations/:suborg_id/farms/:farm_id/', {
				controller : 'FarmController'                                          ,
				templateUrl: api_directory.get_endpoint_partial('agr_restV1_farm_detail'),
				reloadOnSearch: false
			})
			
			// Lot detail
            .when('/suborganizations/:suborg_id/farms/:farm_id/lots/:lot_id/', {
                controller : 'LotController'                                     ,
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_lot'),
                reloadOnSearch: false,
                resolve    : {
                	resolvedIssueMap : 'issueMap'
                }    
            })
            
            // Create Work Ticket
            .when('/suborganizations/:suborg_id/tickets/work/new', {
                controller : 'WorkTicketCreatorController'                                                  ,
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_work_ticket_list', 'html_create'),
                resolve    : {
                	resolvedWorkTicketDayTypeMap   : 'workTicketDayTypeMap'        ,
                	resolvedWorkTicketWorkTypeMap  : 'workTicketWorkTypeMap'       ,
                	resolvedApi_directory          : 'api_directory'               ,
                	resolvedworkTicketWorkerTypeMap: 'routeWorkTicketWorkerTypeMap',
                }
            })
            
            // Work Ticket detail
			.when('/suborganizations/:suborg_id/farms/:farm_id/lots/:lot_id/tickets/work/:ticket_id/', {
                controller : 'WorkTicketController'                                     ,
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_work_ticket_detail'),
            })
            
            // Machine-Usage Ticket detail
            .when('/suborganizations/:suborg_id/farms/:farm_id/lots/:lot_id/tickets/machinery-usage/:ticket_id/', {
                controller : 'MachineryUsageTicketController'                                     ,
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_machine_ticket_detail'),
            })
            
            // Treatment ticket detail
            .when('/suborganizations/:suborg_id/farms/:farm_id/lots/:lot_id/tickets/treatment/:ticket_id', {
                controller : 'TreatmentTicketController'                                     ,
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_treatment_ticket_detail'),
            })
            .when('/suborganizations/:suborg_id/tickets/work', {
                controller: 'WorkTicketListController',
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_suborganization_work_ticket_list'),
            })
            .when('/suborganizations/:suborg_id/tickets/machinery-usage', {
                controller: 'MachineryUsageTicketListController',
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_suborganization_machine_ticket_list'),
            })
            .when('/suborganizations/:suborg_id/tickets/treatment', {
                controller: 'TreatmentTicketListController',
                templateUrl: api_directory.get_endpoint_partial('agr_restV1_suborganization_treatment_ticket_list'),
            });
			
			$route.reload();
		});
		
	}));
	
	agr_module
	.controller('RedirectRootController', (['loggedin_user', 'logged_in_user_organization', '$location'], function (loggedin_user, logged_in_user_organization, $location){
		// If the user's email is not confirmed, redirect to profile
		// Otherwise if the user has no active features, redirect to shop
		// else redirect to suborganizations
		//TODO
		// If the user does not have an active product, redirect to the 
		// shop
		// TODO
		// If the user have an active product, redirect to the SO menu
		// TODO
		
		//FIXME: While all the TODOs are implemented, redirect always to the shop
		
		$location.path('/shop');
	}));
	
	agr_module
	.factory('Farm',(['APIResourceObject', 'Lot'], function (APIResourceObject, Lot) {
		
		function Farm(suborganization_id, farm_id){
			
			var url_params = {
				suborganization_id: suborganization_id
			};
			
			if (farm_id!=undefined)
				url_params['farm_id'] = farm_id
			;
			
			APIResourceObject.call(
			    this,
			    'agr_restV1_farm_list'  ,
			    'agr_restV1_farm_detail',
			    url_params
			    
			);
			
			this.lotSrc = new Lot(suborganization_id, farm_id);
		}
		
		Farm.prototype = Object.create(APIResourceObject.prototype);
		Farm.prototype.constructor = Farm;
		
		Object.defineProperty(Farm.prototype, 'lots', {
			get : function () {
		
				return this.lotSrc.query();
			}
		});
		
		return Farm;
		
	}));
	
	agr_module
	.factory('Lot', (['APIResourceObject'], function (APIResourceObject){
		
		function Lot(suborganization_id, farm_id, lot_id){
			
			var url_params = {
				suborganization_id: suborganization_id,
				farm_id           : farm_id
			};
			
			if (lot_id!=undefined)
				url_params['lot_id'] = lot_id;
			;
			
			APIResourceObject.call(
			    this,
			    'agr_restV1_lot_list',
			    'agr_restV1_lot'     ,
			    url_params
			);
		};
		
		Lot.prototype = Object.create(APIResourceObject.prototype);
		Lot.prototype.constructor = Lot;
		
		return Lot;
	}));

    agr_module
    .factory('WorkTicket',(['APIResourceObject'], function (APIResourceObject) {
        
    	var work_ticket_minimal_data_prototype = {
    			
    		/* Verbose objects (will be send to the server unnested) */
        	work_day : {
        		id: null,
        	},
        	
        	work_type : {
        		id: null,
        	},
        	
        	worker : {
        		id: null
        	},
        	
        	lot : {
        		id: null
        	},
        	
        	description : '',
        	date        : null,
        	hours       : null
    	};
    	
        function WorkTicket(suborganization_id, farm_id, lot_id, ticket_id){
        	
        	this.suborganization_id = Number(suborganization_id);
        	this.farm_id            = farm_id                   ;
        	this.lot_id             = lot_id                    ;
        	this.ticket_id          = ticket_id                 ;
        	
            var url_params = {
                suborganization_id: suborganization_id,
                farm_id           : farm_id           ,
                lot_id            : lot_id            ,
            };
            
            if (ticket_id!=undefined)
                url_params['ticket_id'] = ticket_id
            ;
            
            APIResourceObject.call(
                this,
                'agr_restV1_work_ticket_list'  ,
                'agr_restV1_work_ticket_detail',
                url_params
            );
            
        	// Gives information to .create to know which data must be restored
        	// from the object when sending a request
        	this._set_creation_data_prototype(work_ticket_minimal_data_prototype);
        }
        
        WorkTicket.prototype = Object.create(APIResourceObject.prototype);
        WorkTicket.prototype.constructor = WorkTicket;
        WorkTicket.prototype.prepare_url_args = function (url_args){
        	
        	if (this.lot.farm && this.lot.farm.id)
        		url_args.farm_id = this.lot.farm.id ;
        	else if(this.farm && this.farm.id)
        		url_args.farm_id = this.farm.id;
        		
        	if (this.lot.id)
        		url_args.lot_id = this.lot.id; 
        	
        	return url_args;
        }
        
        WorkTicket.prototype.restore_data= function(data){
        	
        	if(data.date)
        		data.date = new Date(data.date); 
        	
        	if(data.farm)
        		this.farm_id = data.farm.id;
        	
        	if(data.lot)
        		this.lot_id = data.lot.id;
        	
        	this.ticket_id = data.id;
        	
        	
    		APIResourceObject.prototype.restore_data.call(this, data);
    	}
        
        return WorkTicket;
        
    }));
    
    agr_module
    .factory('MachineryUsageTicket',(['APIResourceObject'], function (APIResourceObject) {
        
        function MachineryUsageTicket(suborganization_id, farm_id, lot_id, ticket_id){
            
            var url_params = {
                suborganization_id: suborganization_id,
                farm_id           : farm_id           ,
                lot_id            : lot_id            ,
            }
            
            if (ticket_id!=undefined)
                url_params['ticket_id'] = ticket_id
            ;
            
            APIResourceObject.call(
                this,
                'agr_restV1_machine_ticket_list'  ,
                'agr_restV1_machine_ticket_detail',
                url_params
                
            );
        }
        
        MachineryUsageTicket.prototype = Object.create(APIResourceObject.prototype);
        MachineryUsageTicket.prototype.constructor = MachineryUsageTicket;
        
        return MachineryUsageTicket;
        
    }));
    
    agr_module
    .factory('TreatmentTicket',(['APIResourceObject'], function (APIResourceObject) {
        
        function TreatmentTicket(suborganization_id, farm_id, lot_id, ticket_id){
            
            var url_params = {
                suborganization_id: suborganization_id,
                farm_id           : farm_id           ,
                lot_id            : lot_id            ,
            }
            
            if (ticket_id!=undefined)
                url_params['ticket_id'] = ticket_id
            ;
            
            APIResourceObject.call(
                this,
                'agr_restV1_treatment_ticket_list'  ,
                'agr_restV1_treatment_ticket_detail',
                url_params
                
            );
        }
        
        TreatmentTicket.prototype = Object.create(APIResourceObject.prototype);
        TreatmentTicket.prototype.constructor = TreatmentTicket;
        
        return TreatmentTicket;
        
    }));
	
    agr_module
    .service('typesService', (['$http', '$q', 'api_directory'], function ($http, $q, api_directory){
    	
    	this.createTypeMap = function (endpoint_url, endpoint_args, id_field_name, verbose_field_name){
    		var defer = $q.defer();
    		
    		api_directory
    			.then(function (api_directory){
    				var types_ed_url = api_directory.get_endpoint_url(endpoint_url, endpoint_args);
    				
    				if(!id_field_name)
    					id_field_name = 'id'
    				;
    				
    				if(!verbose_field_name)
    					verbose_field_name = 'verbose'
    				;
    				
    				$http.get(types_ed_url).success(function (types) {
    					var types_map = {};
    					
    					for(var i in types){
    						var type = types[i];
    						types_map[type[id_field_name]] = type[verbose_field_name];
    					}
    					
    					defer.resolve(types_map);
    				});
    				
    			})
    		;
    		
    		return defer.promise;
    	}
    	
    }));
    
	agr_module
	.factory('issueMap', (['typesService'], function (typesService){
		
		return typesService.createTypeMap('agr_restV1_issue_types', [], 'magrama_no', 'text');
	}));
	
	agr_module
	.factory('workTicketDayTypeMap', (['typesService'], function (typesService){
		
		return typesService.createTypeMap('agr_restV1_work_day_types');
	}));
	
	agr_module
	.factory('workTicketWorkTypeMap', (['typesService'], function (typesService){
		
		return typesService.createTypeMap('agr_restV1_work_types');
	}));
	
	agr_module
	.factory('routeWorkTicketWorkerTypeMap', (['typesService', '$route'], function (typesService, $route){
		
		return typesService.createTypeMap('agr_restV1_worker_list', {suborganization_id : $route.current.params.suborg_id}, 'id', 'name');
	}));
	
	agr_module
	.directive('ngLotSelector', (['api_directory', '$compile', '$q', 'Farm', 'Lot'],function (api_directory, $compile, $q, Farm, Lot){
		
		var htmlLinker = function (scope, element, attrs, controller){
			
			var params = scope.params();
			
			var farmRsc = new Farm(params.suborganization_id); 
			
			/* Scope and callbacks*/
			scope.title = django.gettext('Select a Farm');
			
			scope.farm_paged_results = undefined;
			scope.lot_paged_results  = undefined;
			
			scope.selecting_farms = true ;
			scope.selecting_lots  = false;
			
			var selected_farm = null;
			
			scope.onClickFarmItem = function (farm){
				
				selected_farm = farm;
				
				var lorRsc = new Lot(params.suborganization_id, farm.id);
				
				lorRsc.query().then(function (lots){
					scope.lot_paged_results = lots;
					scope.selecting_farms = false;
					scope.selecting_lots  = true;
				});
			}
			scope.onClickLotItem = function (lot){
				
				/* Take the chance that we got the farm object to 
				 * add more useful data to the farm object.
				 */
				lot.farm.name             = selected_farm.name           ;
				lot.farm.sigpac_reference = selected_farm.sigpac_ref_name;
				
				onFinish();
				
				if (params.on_lot_selected)
					params.on_lot_selected(lot);
			}
			
			function onFinish(){
				selected_farm = null;
				
				scope.lot_paged_results  = undefined;
				
				scope.selecting_farms = true ;
				scope.selecting_lots  = false;
			}
			
			scope.onCancel = function () {	
				
				onFinish();
				
				params.on_lot_selected(null);
			}			
			
			/* Concurrent calls to api_directory/paged_farms */
						
			var farmQuery = farmRsc.query();
			
			api_directory
			.then(function (api_directory){
				
				var selector_partial_url = api_directory.get_endpoint_partial('agr_restV1_lot', 'html_selector');
				
				var child = angular.element('<div/>');
				element.append(child);
				
				child.attr('data-ng-include', '"' + selector_partial_url + '"');
				
				var compiled = $compile(child)(scope);
				
			});
			
			var farms_and_directory_ready = $q.all([api_directory, farmQuery]);
			
			farms_and_directory_ready.then(function (resolved_promise_results){
				var farms_paged_results = resolved_promise_results[1];
				
				scope.farm_paged_results = farms_paged_results;
			});
		}
		
		return {
			link      : htmlLinker,
			restrict  : 'A',
			scope     : {
				'params' : '&ngLotSelector'
			}
		};
	}));

	agr_module
	.service('lot_service', (['$location', 'WorkTicket', 'MachineryUsageTicket', 'TreatmentTicket'], function($location, WorkTicket, MachineryUsageTicket, TreatmentTicket) {
	    var self = this;

	    this.init = function(suborg_id, farm_id, lot_id) {
	        self.suborg_id = suborg_id;
	        self.farm_id   = farm_id;
	        self.lot_id    = lot_id;
		    self.show_tickets('work');
	    }

        this.suborg_id     = null;
        this.farm_id       = null;
        this.lot_id        = null;
        this.ticket_type   = null;
        this.paged_tickets = null;
		this.ticket_rsc    = null;

		this.show_tickets = function(type) {
		    $location.search('page', null);
		    switch (type) {
		        case 'work':
		            self.ticket_rsc = new WorkTicket(self.suborg_id, self.farm_id, self.lot_id);
		            break;
		        case 'treatment':
		            self.ticket_rsc = new TreatmentTicket(self.suborg_id, self.farm_id, self.lot_id);
		            break;
		        case 'machinery-usage':
		            self.ticket_rsc = new MachineryUsageTicket(self.suborg_id, self.farm_id, self.lot_id);
		            break;
		    }
		    self.ticket_rsc.query().then(
                function (tickets) {
                    self.ticket_type = type;
                    self.paged_tickets = tickets;
                },
                function (error_message) {
                    self.scope.error_message = error_message;
                }
		    );
		}

		this.showing_all_issues = false;
		this.show_all_issues = function() {
		    self.showing_all_issues = !self.showing_all_issues;
		}

	}));
	
	agr_module
	.controller('FarmListController', (['Farm', 'suborganization_menu_service', '$routeParams', '$scope'], function (Farm, suborganization_menu_service, $routeParams, $scope) {
		
		suborganization_menu_service.init($routeParams.suborg_id);
		var farm_rsc = new Farm($routeParams.suborg_id);
		
		$scope.paged_results = null                       ;
		$scope.error_message = farm_rsc.last_error_message;
		$scope.suborg_id = $routeParams.suborg_id;
		
		farm_rsc.query().then(function (farms){
			$scope.paged_results = farms;
		});
		
	}));
	
	agr_module
	.controller('LotController', (['Lot', '$routeParams', '$scope', 'resolvedIssueMap', 'suborganization_menu_service', 'lot_service'], function (Lot, $routeParams, $scope, resolvedIssueMap, suborganization_menu_service, lot_service){
		
		suborganization_menu_service.init($routeParams.suborg_id);
		var lot_rsc = new Lot(
		    $routeParams.suborg_id , 
		    $routeParams.farm_id   ,
		    $routeParams.lot_id
		);
		
		lot_rsc.read();
		
		$scope.suborg_id   = $routeParams.suborg_id;
		$scope.lot         = lot_rsc               ;
		$scope.lot_service = lot_service           ;
		$scope.issueMap    = resolvedIssueMap      ;

		$scope.lot_service.init(
		    $routeParams.suborg_id ,
		    $routeParams.farm_id   ,
		    $routeParams.lot_id
		);
		
		$scope.error_message = lot_rsc.last_error_message;
		
	}));
    
	agr_module
    .controller('FarmController', (['Farm', 'Lot', 'suborganization_menu_service', '$routeParams', '$scope'], function (Farm, Lot, suborganization_menu_service, $routeParams, $scope) {

        suborganization_menu_service.init($routeParams.suborg_id);
        
        $scope.farm = new Farm($routeParams.suborg_id, $routeParams.farm_id);
        
        $scope.farm.read();

        $scope.error_message_farm = $scope.farm.last_error_message;
        
        var lots_rsc = new Lot($routeParams.suborg_id, $routeParams.farm_id);
        
        $scope.paged_lots = null;

        lots_rsc.query().then(function(lots){
            $scope.paged_lots = lots;
        });
        
        $scope.error_message_lots = lots_rsc.last_error_message;
        
        $scope.suborg_id = $routeParams.suborg_id;
        $scope.farm_id = $routeParams.farm_id;
        
    }));
	
	agr_module
    .controller('WorkTicketController', (['$routeParams', '$scope', 'WorkTicket', 'suborganization_menu_service'], function ($routeParams, $scope, WorkTicket, suborganization_menu_service) {

        suborganization_menu_service.init($routeParams.suborg_id);

        $scope.ticket = new WorkTicket($routeParams.suborg_id, $routeParams.farm_id, $routeParams.lot_id, $routeParams.ticket_id);
        
        $scope.ticket.read();
        
        $scope.error_message = $scope.ticket.last_error_message;

    }));

    agr_module
    .controller('WorkTicketListController', (['$scope', '$routeParams', 'WorkTicket', 'suborganization_menu_service'], function($scope, $routeParams, WorkTicket, suborganization_menu_service) {
        suborganization_menu_service.init($routeParams.suborg_id);

        var ticket_rsc = new WorkTicket($routeParams.suborg_id);
        ticket_rsc.create_view_name = 'agr_restV1_suborganization_work_ticket_list';
        ticket_rsc.query().then(function (tickets) {
            $scope.paged_tickets = tickets;
        });

        $scope.suborg_id = $routeParams.suborg_id;
    }));
	
	agr_module
    .controller('MachineryUsageTicketController', (['$routeParams', '$scope', 'MachineryUsageTicket', 'suborganization_menu_service'], function ($routeParams, $scope, MachineryUsageTicket, suborganization_menu_service) {
        
        suborganization_menu_service.init($routeParams.suborg_id);

        $scope.ticket = new MachineryUsageTicket($routeParams.suborg_id, $routeParams.farm_id, $routeParams.lot_id, $routeParams.ticket_id);
        
        $scope.ticket.read();
        
        $scope.error_message = $scope.ticket.last_error_message;

    }));
	
	agr_module
	.controller(
		'WorkTicketCreatorController', 
		(
			[
			 	'$routeParams'                   , 
			 	'$scope'                         , 
			 	'resolvedApi_directory'          , 
			 	'WorkTicket'                     , 
			 	'Farm'                           , 
			 	'resolvedWorkTicketDayTypeMap'   , 
			 	'resolvedWorkTicketWorkTypeMap'  , 
			 	'resolvedworkTicketWorkerTypeMap',
			 	'$location'                      ,
			 ], 
			 function (
				$routeParams                   , 
				$scope                         , 
				resolvedApi_directory          , 
				WorkTicket                     , 
				Farm                           , 
				resolvedWorkTicketDayTypeMap   , 
				resolvedWorkTicketWorkTypeMap  , 
				resolvedworkTicketWorkerTypeMap,
				$location
			)
	{
		
		var work_ticket = new WorkTicket($routeParams.suborg_id, $routeParams.farm_id, $routeParams.lot_id);
		work_ticket.date = new Date();
		
		$scope.ticket = work_ticket;
		
		$scope.day_types  = resolvedWorkTicketDayTypeMap   ;
		$scope.work_types = resolvedWorkTicketWorkTypeMap  ;
		$scope.workers    = resolvedworkTicketWorkerTypeMap;
		
		
		function setLot(lot){
			
			work_ticket.lot = lot;
			
			work_ticket.farm = lot.farm;
		}
		
		function onLotSelected (lot) {
			$scope.is_selecting_farm = false;
			
			if (lot!=null)
				setLot(lot);
		}
		
		$scope.lotSelectorParams = {
			suborganization_id : $routeParams.suborg_id,
			on_lot_selected    : onLotSelected
		}
		
		$scope.onStartFarmSelection  = function () {
			$scope.is_selecting_farm = true;
		}
		
		$scope.onTicketCreated = function (ticket){
			$location.path('/suborganizations/'       + 
			               ticket.suborganization_id  + 
			               '/farms/' + ticket.farm.id + 
			               '/lots/'  + ticket.lot.id  + 
			               '/tickets/work/' + ticket.id
			);
		}
		
		$scope.error_message   = work_ticket.last_error_message;
		$scope.success_message = work_ticket.last_success_message;
		
	}));
	
	agr_module
    .controller('MachineryUsageTicketController', (['$routeParams', '$scope', 'MachineryUsageTicket'], function ($routeParams, $scope, MachineryUsageTicket) {
        
        $scope.ticket = new MachineryUsageTicket($routeParams.suborg_id, $routeParams.farm_id, $routeParams.lot_id, $routeParams.ticket_id);
        
        $scope.ticket.read();
        
        $scope.error_message = $scope.ticket.last_error_message;

    }));

    agr_module
    .controller('MachineryUsageTicketListController', (['$scope', '$routeParams', 'MachineryUsageTicket', 'suborganization_menu_service'], function($scope, $routeParams, MachineryUsageTicket, suborganization_menu_service) {
        suborganization_menu_service.init($routeParams.suborg_id);

        var ticket_rsc = new MachineryUsageTicket($routeParams.suborg_id);
        ticket_rsc.create_view_name = 'agr_restV1_suborganization_machine_ticket_list';
        ticket_rsc.query().then(function (tickets) {
            $scope.paged_tickets = tickets;
        });

        $scope.suborg_id = $routeParams.suborg_id;
    }));
	
	agr_module
    .controller('TreatmentTicketController', (['$routeParams', '$scope', 'TreatmentTicket', 'suborganization_menu_service'], function ($routeParams, $scope, TreatmentTicket, suborganization_menu_service) {
        
        suborganization_menu_service.init($routeParams.suborg_id);

        $scope.ticket = new TreatmentTicket($routeParams.suborg_id, $routeParams.farm_id, $routeParams.lot_id, $routeParams.ticket_id);
        
        $scope.ticket.read();
        
        $scope.error_message = $scope.ticket.last_error_message;

    }));

    agr_module
    .controller('TreatmentTicketListController', (['$scope', '$routeParams', 'TreatmentTicket', 'suborganization_menu_service'], function($scope, $routeParams, TreatmentTicket, suborganization_menu_service) {
        suborganization_menu_service.init($routeParams.suborg_id);

        var ticket_rsc = new TreatmentTicket($routeParams.suborg_id);
        ticket_rsc.create_view_name = 'agr_restV1_suborganization_treatment_ticket_list';
        ticket_rsc.query().then(function (tickets) {
            $scope.paged_tickets = tickets;
        });

        $scope.suborg_id = $routeParams.suborg_id;
    }));
	
})();