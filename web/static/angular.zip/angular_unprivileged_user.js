"use strict";

(function () {
    
    var user_module = angular.module('user_unpriviliged', ['user_common', 'api']);
            
    user_module.run((['api_directory', '$rootScope', '$route'],function(api_directory, $rootScope, $route){
        api_directory.then(function (api_directory) {
            $globalRouteProvider
            // Even using UserCtrl, we have no permalink to load the page. We rely that other
            // element will take care of the situation.
            .when('/',{ 
                redirectTo: '/login'
            })
            .when('/login',{ 
                templateUrl: api_directory.get_endpoint_partial('profile_restV1_LoginAPIView'),
                controller : 'LoginCtrl'                                                        ,
            })
            .when('/register',{ 
                templateUrl: api_directory.get_endpoint_partial('profile_restV1_UserAPIListView'),
                controller : 'RegisterCtrl'                                                        ,
            })
            .otherwise({
                redirectTo: '/'
            });
            
            $route.reload();
        });
    }));

    //------------------------------------------------------------------------------
    
    user_module
    .service('login_service', (['$window', '$http', 'api_directory', '$cookies'], function ($window, $http, api_directory, $cookies){
        
        this.email              = ''  ;
        this.password           = ''  ;
        this.last_error_message = {
            detail       : null,
            named_details: null
        };
        
        this.last_success_message = {
            detail       : null,
            named_details: null
        };
        
        this.login = function (){
            var self = this;
            
            api_directory.then(function (api_directory){
                
                var login_url = api_directory.get_endpoint_url('profile_restV1_LoginAPIView');
                
                var credentials = {
                    email   : self.email   ,
                    password: self.password
                }
                
                $http.post(login_url, credentials)
                .success(function(message) {
                	self.last_error_message.detail          = null;
                	self.last_error_message.named_details   = null;
                	self.last_success_message.named_details = null
                	self.last_success_message.detail        = 
                		django.gettext('Successfully logged in, redirecting to the main menu...')
                	;
                    
                    $cookies.user_id = message['named_details']['id'];
                    $window.location.reload();
                    
                })
                .error(function(message) {
                    /* Instead of replacing the whole object, we replace its attributes
                     * so that we can use two way data binding easily
                     */
                    self.last_error_message.detail        = message.detail       ;
                    self.last_error_message.named_details = message.named_details;
                });
            });
        }
        
    }));
    
    user_module
    .service('register_service', (['UserInformation', 'login_service'], function (UserInformation, login_service){
        var self = this;
    	
        var empty_user = new UserInformation(null);
        
        this.dataset = {
            first_name: null,
            last_name : null,
            email     : null,
            password  : null,
            tc        : null,
        };
        
        function successRegisterCallback(){
        	self.last_error_message.detail          = null;
        	self.last_error_message.named_details   = null;
        	self.last_success_message.named_details = null;
        	self.last_success_message.detail        = 
        		django.gettext('Successfully registered, logging in...')
        	;
        	
        	login_service.email    = self.dataset.email   ;
        	login_service.password = self.dataset.password;
        	
        	login_service.login();
        }
        
        function failRegisterCallback(message){
        	self.last_error_message.detail        = message.detail       ;
        	self.last_error_message.named_details = message.named_details;
        }
        
        this.register = function (){
        	empty_user.create(this.dataset).then(
    			successRegisterCallback,
    			failRegisterCallback   
        	)
        }
        
        this.last_error_message = {
        	detail        : null,
        	named_details : null,
        }
        
        this.last_success_message = {
        	detail        : null,
        	named_details : null,
        }
        
    }));
    
    //------------------------------------------------------------------------------
    
    user_module
    .controller('LoginCtrl', (['$scope', 'login_service'], function ($scope, login_service){
    	
        $scope.login_service   = login_service                     ;
        $scope.error_message   = login_service.last_error_message  ;
        $scope.success_message = login_service.last_success_message;
        
    }));
    
    user_module
    .controller('RegisterCtrl', (['$scope', 'register_service'], function ($scope, register_service){
    	
        $scope.register_service = register_service                     ;
        $scope.error_message    = register_service.last_error_message  ;
        $scope.success_message  = register_service.last_success_message;
        
    }));
    
})();
