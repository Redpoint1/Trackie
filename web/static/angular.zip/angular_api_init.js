"use strict";

// Global reference to the route provider to be used by
// modules to load routes lazily
var $globalRouteProvider;

(function (){ 
	
	var gettext = (window.django && window.django.gettext) || function (msg){return msg};
	
	var API = function (api_directory_data, version, $location) {
		/*
		 * Prototype for representing singletons that access the
		 * API bootstrap URL for API information
		 */
		
		var api_data    = JSON.parse(api_directory_data);
		var api_version = version; 
		
		var _get_invalid_endpoint_args = function(arg_patterns, arg_values){
			
			var invalid_args = []
			
			for (var arg_name in arg_patterns) {
				var arg_value;
				
				if(!(arg_name in arg_values))
					arg_value = '';
				else
					arg_value = arg_values[arg_name];
				
				var arg_regex = new RegExp(arg_patterns[arg_name]);
				
				if(!arg_regex.test(arg_value))
					invalid_args.push(arg_name)
				;
			}
			
			return invalid_args
		}
		
		var _build_url = function (ed_data, args){
			
			var template = ed_data.url;
			
			for (var arg_name in ed_data.args) {
				var regex = new RegExp('<' + arg_name + '>');
				template = template.replace(regex, args[arg_name]);
			}
			
			return template;
		}
		
		return {
			get_endpoint_url: function(endpoint_name, args){
				
				var ed_data = this.get_endpoint_info(endpoint_name);
				
				if (!ed_data)
					throw 'Endpoint ' + endpoint_name + ' does not exists in the Api directory'
				;
				var invalid_args = _get_invalid_endpoint_args(ed_data.args, args);
				
				if(invalid_args.length)
					throw "The following arguments do not match their URL pattern: " + invalid_args
				;
				
				var query_params = $location.search();
				var param_tokens = [];
				
				for (var paramName in query_params) {
					var paramValue = query_params[paramName];
					param_tokens.push(encodeURIComponent(paramName) + '=' + encodeURIComponent(paramValue));
				}


				var url = _build_url(ed_data, args);
				
				if(param_tokens.length){
					url += '?' + param_tokens.join('&');
				}
				
				return url;
			},
			get_endpoint_info: function(endpoint_name){
				return api_data[endpoint_name]
			},

			get_endpoint_partial: function (endpoint_name, partial){
				
				if (!partial) {
					partial = 'html'
				}
				
				if (!(endpoint_name in api_data))
					throw 'Endpoint ' + endpoint_name + ' does not exists in the Api directory'
				;
				
				return api_data[endpoint_name].partials[partial];
			},
			get_endpoint_names: function (){
				return Object.keys(api_data);
			},
			get_version: function (){
				return api_version;
			}
		}
	};
	
	// Angular starts here
	//TODO: remove verbose comments when developers
	// get trained at angular
	var apiModule = angular
		.module('api',['ngRoute','ngResource', 'naif.base64', 'corelib_utils'])
		// Replaces render markers so that we can use them in Django
		// templates
		.config(function($interpolateProvider) {
			$interpolateProvider.startSymbol('{$');
			$interpolateProvider.endSymbol('$}');
		})
		// Creates a global reference to the route provider so that
		// we can initialize it later with API data
		.config(function($routeProvider) {
			$globalRouteProvider = $routeProvider;
		})
		// Forces angular to not remove trailing slashes from resource
		// urls, faster because it avoids 303 for most endpoints
		.config(function($resourceProvider) {
		  $resourceProvider.defaults.stripTrailingSlashes = false;
		})
		.config(function($httpProvider) {
		  $httpProvider.defaults.useXDomain = true;
		  delete $httpProvider.defaults.headers.common['X-Requested-With'];
		})
		.config(['$httpProvider', function($httpProvider) {
			$httpProvider.defaults.xsrfCookieName = 'csrftoken';
			$httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
		}])
	;
	
	function ApiPagedObjectList(pages_data){
		this._set_data(pages_data);
	}
		ApiPagedObjectList._extract_page_get_arg = function (url){
			
			var page = 0;
			
			var qs = /\?(.*)$/.exec(url);
			
			if(qs){
				qs = qs[1];
				
				var matches = /(?:^page=(\d*)|&page=(\d*))/.exec(qs);
				
				if (matches){
					if(matches[1]){
						page = parseInt(matches[1]);
					}else{
						page = parseInt(matches[2]);
					}
				}
				
				if (page === NaN){
					page = 0;
				}
			}
			
			return page;
		};
		
        ApiPagedObjectList._replace_page_arg_value = function (url, value){
            
            var replaced = url.replace(/page=(\d*)/, "page="+value);
            
            return replaced;
        };
		
		ApiPagedObjectList.prototype = {
			
			objs      : undefined,
			page_count: undefined,
			
			current_page: undefined,
			items_per_page: undefined,
			
			next_frame_ed_url: undefined,
			prev_frame_ed_url: undefined,
			
			has_prev: function () {
				return Boolean(this.prev_frame_ed_url);
			},
			has_next: function () {
				return Boolean(this.next_frame_ed_url);
			},
			
			first: function (){
			  if(this.has_prev()){
			      var replaced_url = ApiPagedObjectList._replace_page_arg_value(this.prev_frame_ed_url, 1);
			      this.$http.get(replaced_url)
                  .success(function (data){
                      this._set_data(data);
                      //this.$location.search('page', this.current_page);
                  }.bind(this));
			  }  
			},
			last: function (){
	              if(this.has_next()){
	                  var last_page = Math.floor(this.page_count/this.items_per_page+1);
	                  var replaced_url = ApiPagedObjectList._replace_page_arg_value(this.next_frame_ed_url, last_page);
	                  this.$http.get(replaced_url)
	                  .success(function (data){
	                      this._set_data(data);
	                      //this.$location.search('page', this.current_page);
	                  }.bind(this));
	              }  
	            },
			next : function (){
			    if(this.has_next()){
    				this.$http.get(this.next_frame_ed_url)
    					.success(function (data){
    						this._set_data(data);
    						//this.$location.search('page', this.current_page);
    					}.bind(this));
			    }
			},
			prev: function (){
			    if(this.has_prev()){
    				this.$http.get(this.prev_frame_ed_url)
    					.success(function (data){
    						this._set_data(data);
    						//this.$location.search('page', this.current_page);
    					}.bind(this));
			     }
			},
			
			_set_data : function(pages_data){
				this.objs       = pages_data.results;
				this.page_count = pages_data.count  ;
				
				this.next_frame_ed_url = pages_data.next    ;
				this.prev_frame_ed_url = pages_data.previous;
				
				// Django rest API do not retnext_frame_ed_urlzurns the current page.
				// Calculate from either next_frame_ed_url or prev_frame_ed_url
				var calcd_page = 1;
				var to_add     = 0;
				if (this.has_next()){
					calcd_page = ApiPagedObjectList._extract_page_get_arg(this.next_frame_ed_url);
					to_add     = -1;
				}else if(this.has_prev()){
					calcd_page = ApiPagedObjectList._extract_page_get_arg(this.prev_frame_ed_url);
					to_add     = 1; 
				}
				
				this.current_page = calcd_page + to_add;
				
				if(this.has_next()){
                    this.items_per_page = this.objs.length;
                }
			},
		};
	//---
	
	apiModule
	.factory('ApiPagedObjectList', (['$http', '$location'], function ($http, $location){
		
		// Add to the ApiPagedObjectList the dependencies that must be injected
		// (and thus, can only be obtained via factory/service)
		ApiPagedObjectList.prototype.$http     = $http    ;
		ApiPagedObjectList.prototype.$location = $location;
		
		return ApiPagedObjectList;
	}));
	
	function ApiObject(instance_data){
		
		this._set_data(instance_data);
	}
		ApiObject.prototype = {
			_set_data: function (obj_data){	
				this.data = obj_data;
				
				for (var attr_name in obj_data){
					// exclude hidden parameters
					if(!attr_name.match(/^\$/))
						this[attr_name] = obj_data[attr_name];
				}
			}
		};
	//---
	
	apiModule
	.factory('ApiObject', function (){
		// Converts ApiObject into dependency that can
		// be injected
		return ApiObject;
	});
	
    apiModule
    .factory('APIResourceObject', (['$resource', 'api_directory', 'ApiObject', '$q', 'ApiPagedObjectList'], function (api_directory, ApiObject, $resource, $q, ApiPagedObjectList) {
            	
    	function APIResourceObject(create_view_name, update_view_name, url_args, query_params){
        	var self = this;
    		
        	self.data = {};
        	
        	self.last_success_message = {
        		detail        : null,
        		named_details: null,
        	};
        	self.last_error_message   = {
        		detail        : null,
        		named_details: null,
        	};
        	
        	this.url_args     = url_args    ;
        	this.query_params = query_params;
        	
        	this.create_view_name = create_view_name;
        	this.update_view_name = update_view_name;
        }    	
    	
        APIResourceObject.prototype = Object.create(ApiObject.prototype);
        APIResourceObject.prototype.constructor = APIResourceObject;
        //---
	        /* Creates lazily two resources for creation and update endpoints
	    	 * as normally they are in different endpoints (aka /objects/ 
	    	 * for creation and /objects/<pk> for update).
	    	 * 
	    	 * The user may provide only the creation view name.
	    	 */
        
        	Object.defineProperty(APIResourceObject.prototype, 'create_query_resource_promise', {
        		get: function () {
        			var self = this;
        			
        			return api_directory.then(function (api_directory){
        				var processed_url_args = self.prepare_url_args(self.url_args);
        				
    	        		var create_api_url = api_directory.get_endpoint_url(self.create_view_name, processed_url_args, self.query_params);
    	        		
    	        		return $resource(create_api_url, {}, {
                			post : {method: 'POST'},
                			query: {
                				method: 'GET',
                				transformResponse: function (data) {
                					
                					var parsed_data = JSON.parse(data);
                					
                					// The list is not paginated, simulate it
                					if (angular.isArray(parsed_data)){
                						parsed_data = {
            								"count": parsed_data.length, 
            							    "next": null, 
            							    "previous": null, 
            							    "results": parsed_data
                						};
                					}
                					
                					return parsed_data;
                				}
                			}
                		});
    	        	});
        		}
        	});
        	
        	Object.defineProperty(APIResourceObject.prototype, 'update_resource_promise', {
        		get: function () {
        			var self = this;
        			
        			return api_directory.then(function (api_directory){
        				var processed_url_args = self.prepare_url_args(self.url_args);
        				
        	    		var update_api_url = api_directory.get_endpoint_url(self.update_view_name, processed_url_args, self.query_params);
        	    		
        	    		return $resource(update_api_url, {},{
                			get   : {method: 'GET'   },
                			put   : {method: 'PUT'   },
                			delete: {method: 'DELETE'} 
                		});
        	    	});
        		}
        	});
        	

        	
        	APIResourceObject.prototype._set_creation_data_prototype = function (data_prototype){
        		/**
            	 * If the data prototype is not set before making contact with the server,
            	 * it would be, for example, impossible to call this.create() without 
            	 * arguments as it would be impossible for the resource manager to know
            	 * which fields from the current object do he have to send to the server.
            	 */
				this._set_data(angular.copy(data_prototype));
			}
        	
        	APIResourceObject.prototype.restore_data= function(data){
        		this._set_data(data);
        	}
        	
        	APIResourceObject.prototype.prepare_url_args = function (url_args){
        		/**
        		 * This function is intended to obtain URL parameters from the 
        		 * object data.
        		 */
        		
        		return url_args;
        	}
        	
        	function isBasicType(value){
        		var is_basic =  
	        		typeof value == 'number'  ||
	 			   	typeof value == 'string'  ||
	 			   	typeof value == 'boolean' ||
	 			    value instanceof Array    ||
	 			    value instanceof Date     ||
	 			    value === null
	 			;
        		
        		return is_basic;
        	}
        	
        	APIResourceObject.prototype.prepare_data = function (data, data_prototype){
        		var dataset = {};
        		
        		if(!data_prototype)
        			data_prototype = this.data;
        		
        		for (var data_name in data_prototype){
        			var data_value = data[data_name];
        			
        			if(data_value === undefined)
        				data_value = data_prototype[data_name]
        			;
        			
        			if (data_value === undefined)
        				continue
        			;
        			
        			if(isBasicType(data_value)){
        				dataset[data_name] = data_value;
        			}else{
        				/*
        				 * We do not allow creating nor updating objects nestedly with an id.
        				 * Any nested object with an ID attribute will be interpreted as a 
        				 * verbose related object
        				 */
        				if(isBasicType(data_value.id))
        					data_value = data_value.id;
        				else{
	        				var subprototype = data_prototype[data_name];
	        				
	        				if(data_value!=subprototype)
	        					data_value = this.prepare_data(data_value, subprototype);
        				}
    						
        			}
        			
        			dataset[data_name] = data_value;
        		}
        		
        		return dataset;
        	}
        	
//        	APIResourceObject.prototype.prepare_data= function(data){
//        		var dataset;
//    			
//        		if (this.data_prototype){
//        			dataset = this.prepare_data_from_prototype(data, this.data_prototype);			
//        		} else {
//        			dataset = {};
//        			
//        			for (var data_name in data){
//            			var data_value = data[data_name];
//            			
//            			if (data_value === undefined)
//            				continue
//            			;
//            			
//            			dataset[data_name] = data_value;
//            		}
//        		}
//    			
//    			return dataset;
//        	}
        	
        	APIResourceObject.prototype.getSuccessMessageDetail = function(operation_type){
        		
        		var message;
        		
        		switch(operation_type){
        			case 'create':
        				message = gettext('Successfully created.');
        				break;
        			case 'read':
        				message = gettext('Successfully read.');
        				break;
        			case 'update':
        				message = gettext('Successfully updated.');
        				break;
        			case 'delete':
        				message = gettext('Successfully deleted.');
        				break;
        			case 'query':
        				message = gettext('Objects retrieved successfully.');
        				break;
        			default:
        				message = gettext('Operation performed successfully.');
        		}
        	
        		return message;
        	}
        	
        	APIResourceObject.prototype.getSuccessMessageNamedDetails = function(operation_type){
        		
        		return null;
        	};
        	
        	APIResourceObject.prototype.processSuccess = function(data, operation_type){
	    		this.restore_data(data);
	    		
	    		this.last_error_message.detail        = null;
	    		this.last_error_message.named_details = null;
	    		
	    		this.last_success_message.detail        = 
	    			this.getSuccessMessageDetail      (operation_type);
	    		this.last_success_message.named_details = 
	    			this.getSuccessMessageNamedDetails(operation_type);
	    		
	    		return this;
	    	}
        	
        	APIResourceObject.prototype.processQuerySuccess = function (datalist, operation_type){
        		
    			var object_list = new ApiPagedObjectList(datalist);
        		
        		this.last_error_message.detail        = null;
	    		this.last_error_message.named_details = null;
	    		
	    		this.last_success_message.detail        = 
	    			this.getSuccessMessageDetail      (operation_type);
	    		this.last_success_message.named_details = 
	    			this.getSuccessMessageNamedDetails(operation_type);
        		
        		return object_list;
        	}
        	
        	APIResourceObject.prototype.processError = function(response_or_error) {
            	
            	var error_message; 
            	
            	
            	if ('data' in response_or_error)
            		error_message = response_or_error.data
        		else
        			error_message = response_or_error
            	;
            	
            	error_message = error_message || {};
            	
            	if (!('detail' in error_message))
            		error_message.detail = 'Unknown internal error, please contact staff.';
            	;
            	
            	this.last_success_message.detail        = null;
            	this.last_success_message.named_details = null;
            	
            	// Try to translate the error returned by server message
            	var translated_named_details = {};
            	for(var error_detail_name in error_message.named_details){
            		var translated_error;
            		
            		var named_error = error_message.named_details[error_detail_name];
            		
            		if (!(named_error instanceof Array))
            			translated_error = gettext(named_error);
        			else{
            			var named_error_list = [];
            			for (var idx in named_error){
            				named_error_list.push(gettext(named_error[idx]));
            			}
            			
            			translated_error = named_error_list;
            		}
            		
            		translated_named_details[error_detail_name] = translated_error;
            	}
            	
            	this.last_error_message.detail        = gettext(error_message.detail);
            	this.last_error_message.named_details = translated_named_details     ; 
            	
                return error_message;
            }
        	

        	APIResourceObject.prototype.query = function (page) {
    			var self = this;
        		
        		var deferred = $q.defer();
        		
        		var params = {};
        		if (page)
        			params.page = page;
        			
        		
        		this.create_query_resource_promise
        		.then(function (resource){
        			resource.query(params,
    					function (data){
    				    	deferred.resolve(self.processQuerySuccess(data, 'query'));
    				    },
    				    function(errorOrResponse){
    				    	deferred.reject(self.processError(errorOrResponse));
    				    }
        			);
        		});
        		
                return deferred.promise;     		
        	}
        	
        	APIResourceObject.prototype.create = function(dataset){
        		var self = this;
        		
        		var deferred = $q.defer();
        		
        		this.create_query_resource_promise
        		.then(function (resource){
        			
        			if (!dataset)
    					dataset = self.prepare_data(self);	
        			
        			
    				resource.post({}, dataset, 
    				    function (data){
    				    	deferred.resolve(self.processSuccess(data, 'create'));
    				    },
    				    function(errorOrResponse){
    				    	deferred.reject(self.processError(errorOrResponse));
    				    }
    				);
    			});
        		
        		return deferred.promise;
        	};
        	        	
        	APIResourceObject.prototype.read = function(){
        		var self = this;
        		
        		var deferred = $q.defer();
        		
        		this.update_resource_promise
        		.then(function (resource){
        			resource.get(
    					function (data){
    				    	deferred.resolve(self.processSuccess(data, 'read'));
    				    },
    				    function(errorOrResponse){
    				    	deferred.reject(self.processError(errorOrResponse));
    				    }
        			);
        		});
        		
                return deferred.promise;
            };
            
            APIResourceObject.prototype.update = function(){
            	var self = this;
                
            	var deferred = $q.defer();
        		
        		this.update_resource_promise
        		.then(function (resource){
        			
        			var dataset = self.prepare_data(self.data);
        			
        			resource.put({},dataset,
    					function (data){
				    		deferred.resolve(self.processSuccess(data, 'update'));
					    },
					    function(errorOrResponse){
					    	deferred.reject(self.processError(errorOrResponse));
					    }
        			);
        		});
        		
                return deferred.promise;
            };
            
            APIResourceObject.prototype.delete = function(){
            	var self = this;
            	
            	var deferred = $q.defer();
            	
            	this.update_resource_promise
            	.then(function (resource){
        			resource.delete({},
    					function (data){
		    				deferred.resolve(self.processSuccess(data, 'delete'));
					    },
					    function(errorOrResponse){
					    	deferred.reject(self.processError(errorOrResponse));
					    }
        			);
        		});
            	
            	return deferred.promise;
            };
        //---
    	
        return APIResourceObject;
    }));
		
	apiModule
	.factory('api_directory', (['$resource', '$location'],function ($resource, $location){
		
		var api_res = $resource('/api/v1/',{},{
			'get': {
				method: 'GET',
				transformResponse: function(data, headers){
					
					return API(data, 'v1', $location);
				}
			}
		});
		
		return api_res.get().$promise;
		
	}));
	
	apiModule
	.service('flash_message_service', ([], function() {
		this.message = null;
	}));
	
	apiModule
    .directive('paginator', function($templateCache, $compile){

        return {
            scope: {
                paginator: '&paginator',
            },
            restrict: 'A',
            template: '\
                <nav>\
                <ul class="pagination">\
                  <li data-ng-class="paginator().has_prev() ? \'\' : \'disabled\'" data-ng-click="paginator().first()">\
                    <span>\
                      <span aria-hidden="true"">&laquo;</span>\
                    </span>\
                  </li>\
                  <li data-ng-class="paginator().has_prev() ? \'\' : \'disabled\'" data-ng-click="paginator().prev()">\
                    <span>\
                      <span aria-hidden="true">'+gettext("previous")+'</span>\
                    </span>\
                  </li>\
                  <li>\
                    <span>{$ paginator().current_page $}<span class="sr-only">(current)</span></span>\
                  </li>\
                  <li data-ng-class="paginator().has_next() ? \'\' : \'disabled\'" data-ng-click="paginator().next()">\
                    <span>\
                      <span aria-hidden="true">'+gettext("next")+'</span>\
                    </span>\
                  </li>\
                  <li data-ng-class="paginator().has_next() ? \'\' : \'disabled\'" data-ng-click="paginator().last()">\
                    <span>\
                      <span aria-hidden="true">&raquo;</span>\
                    </span>\
                  </li>\
                </ul>\
              </nav>',
        };
    });
	
})();