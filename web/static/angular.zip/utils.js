"use strict";

(function () {
	
	var corelib_utils = angular.module('corelib_utils', []);
	
	corelib_utils.run(['$rootScope', function ($rootScope){

		$rootScope.gettext = django && django.gettext || function (msg){return msg};
		
	}]);
	
	// Directive for Form Validation
	corelib_utils.directive('watchValidForm', ['$timeout', function($timeout) {
        return {
        	scope: {},
            link: function(scope, element, attrs) {
            	
            	var parentScope = scope.$parent;
            	var curForm = element[0];
            	var loading = angular.element(document.querySelector('#loading'));
            	var header = angular.element(document.querySelector('#header'))[0];
            	var content = angular.element(document.querySelector('#content'))[0];

            	scope.formElements = curForm.querySelectorAll("input[class^='ng-']");
            	
            	var fieldValidationInit = function() {
            		loading.removeClass("loading");
            		var $q = function(query){return element[0].querySelectorAll(query);};
            		angular.forEach(scope.formElements, function(value, key) {
            			if (value.name) {
            				if (value.type == "password" || value.type == "file" || value.name == "logo" || value.name == "fakelogo") {
    							parentScope[attrs.name][value.name].$viewValue = undefined;
    							parentScope[attrs.name][value.name].$render();
            				}
            				parentScope[attrs.name][value.name].$setPristine();
            			}
					});
        		}
            	
            	var fieldValidationErrors = function() {
        			angular.forEach(parentScope.error_message.named_details, function(value, key) {
        				//FIXME We prepare the directive to take care of username/email binding
        				// so that the response from server could be about either two
        				if (!parentScope[attrs.name][key] && key == "username")
        						key = "email";
        				
        				if (parentScope[attrs.name][key]) {
							parentScope[attrs.name][key].$setDirty();
	        				
	        				var el = angular.element(document.getElementById(key));
	        				if (el.hasClass('ng-valid-pattern') || el.hasClass('ng-invalid-pattern')) {
								parentScope[attrs.name][key].$setValidity('pattern', false);
	        				}
        				}
        				else {
        					angular.forEach(scope.formElements, function(value, key) {
        						parentScope[attrs.name][value.name].$setDirty();
        						var el = angular.element(document.getElementById(value.name));
    						
    	        				if (el.hasClass('ng-valid-required') || el.hasClass('ng-invalid-required'))
    								parentScope[attrs.name][value.name].$setValidity('required', false);
    						});
        				}
        			});
        		}
            	
            	element.on('submit', function() {
            		// We set the height of the loading widget
            		loading.height(header.offsetHeight + content.offsetHeight);
            		loading.addClass("loading");
            		if(parentScope.error_message!=undefined)
            			parentScope.error_message.detail = null;
            		if(parentScope.success_message!=undefined)
            			parentScope.success_message.detail = null;
                 });
            	
            	parentScope.$watch('error_message', function(newValue, oldValue) {
            		if (!$.isEmptyObject(newValue) && newValue.detail !== undefined && newValue.detail !== null && newValue.detail !== "") {
            			fieldValidationInit();
            			fieldValidationErrors();
            		}
                    
                }, true);
            	
            	parentScope.$watch('success_message', function(newValue, oldValue) {
            		if (!$.isEmptyObject(newValue) && newValue.detail !== undefined && newValue.detail !== null && newValue.detail !== "") {
            			fieldValidationInit();
            			show_success_message();
            		}
                }, true)
            	
            	var timeoutPromise = null;
            	parentScope.hide_success_message = true;
            	var show_success_message = function(text, timeout) {
            		var self = parentScope;
            		
            		if (timeout === undefined || timeout === null || timeout === 0) 
            			timeout = 2500;
        			
            		if (text !== undefined && text !== null && text !== "") 
        				self.success_message.detail = text;

        			if (timeoutPromise) $timeout.cancel(timeoutPromise);
        			
        			self.hide_success_message = false;
        			
        			timeoutPromise = $timeout(function () { self.hide_success_message = true; timeoutPromise = null;}, timeout);
            	}
            	
        		return true;
            }
        };
    }]);
	
})();