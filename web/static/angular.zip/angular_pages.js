"use strict";

(function () {
	
	var page_module = angular.module('cms', ['api','ngResource','ngSanitize']);
			
	page_module.run((['api_directory', '$rootScope', '$route'],function(api_directory, $rootScope, $route){
		api_directory.then(function (api_directory) {
			$globalRouteProvider
			// Even using PageCtrl, we have no permalink to load the page. We rely that other
			// element will take care of the situation.
			.when('/',{ 
				templateUrl: api_directory.get_endpoint_partial('cms_restV1_PublicPageAPIView'),
				controller : 'PageCtrl'                                                        ,
			})
			.when('/pages/', {
				templateUrl: api_directory.get_endpoint_partial('cms_restV1_PublicPageSummaryListAPIView'),
				controller : 'PageSummaryListCtrl'														  ,
			})
			.when('/pages/:permalink',{ 
				templateUrl: api_directory.get_endpoint_partial('cms_restV1_PublicPageAPIView'),
				controller : 'PageCtrl'                                                        ,
			})
			.otherwise({
				redirectTo: '/'
			});
			
			$route.reload();
		});
	}));
	
	page_module
	.factory('MenuItem', (['ApiObject'], function (ApiObject){
		
		function MenuItemApiObject(data, parent, root_menu){
			ApiObject.call(this, data);
			
			this['is_' + this.type] = true;
			
			this.parent    = parent   ;
			this.root_menu = root_menu;
			
			if (parent.header_level){
				this.header_level = parent.header_level + 1;
			}else{
				this.header_level = 1;
			}
			
			if (this.is_menu){
				this.name = this.verbose;
			}else if(this.is_page || this.is_postpage){
				
				this.is_page = true;
				
				this.root_menu.clickables[this.permalink] = this;
				
				if (!this.root_menu.firstClickableItem){
					this.root_menu.firstClickableItem = this;
				}
			}
			
			if (this.menu_items){
				for(var i in this.menu_items){
					var child_menu = new MenuItemApiObject(this.menu_items[i], this, root_menu)
					this.menu_items[i] = child_menu;
				}
			}
		};
		
		MenuItemApiObject.prototype = Object.create(ApiObject.prototype);
		MenuItemApiObject.prototype.is_menu      = false;
		MenuItemApiObject.prototype.is_page      = false;
		MenuItemApiObject.prototype.is_postpage  = false;
		
		MenuItemApiObject.prototype.classes 	 = function (selectedItem){
			if(selectedItem){
				if (
					((this.header_level == 1) && this.has_sub_item(selectedItem)) 			||
					((this.header_level == 1) && (selectedItem.permalink == this.permalink))
				){
					return "selected";
				}
			}
			
			return "";
		};
		
		MenuItemApiObject.prototype.has_sub_item = function (selectedItem){
			if (this.menu_items) {
				for(var i=0; i <this.menu_items.length; i++){
					if(this.menu_items[i] == selectedItem){
						return true;
					}
				}
			}
			
			return false;
		};
		
		MenuItemApiObject.prototype.constructor = MenuItemApiObject
		
		return MenuItemApiObject
	}));
	
	page_module
	.factory('Menu', (['MenuItem', 'ApiObject'], function (MenuItem, ApiObject) {
		
		function MenuApiObject(data){
			ApiObject.call(this, data);
			
			this.header_level = 0;
			// Dictionary of permalink -> MenuItem
			this.clickables   = {};
			
			for (var i in this.menu_items){
				this.menu_items[i] = new MenuItem(this.menu_items[i], this, this);
			}
		};
		
		MenuApiObject.prototype = Object.create(ApiObject.prototype);
		
		MenuApiObject.prototype.constructor = MenuApiObject;
		
		return MenuApiObject;
	}));
	
	page_module
	.factory('PageSummaryList', (['ApiPagedObjectList'],function (ApiPagedObjectList){	
		function PageSummaryList(data){
			ApiPagedObjectList.call(this, data);
		}
		
		PageSummaryList.prototype = Object.create(ApiPagedObjectList.prototype);
		//--
		
		PageSummaryList.prototype.constructor = PageSummaryList;
		
	    return PageSummaryList;
	}));
	
	page_module
	.factory('page_summary_list_init', (['api_directory', '$resource', 'PageSummaryList'], function (api_directory, $resource, PageSummaryList){
		
		var page_summary_list_init = function (){
			
			return api_directory

				.then(function (api_directory){
					var url = api_directory
						.get_endpoint_url('cms_restV1_PublicPageSummaryListAPIView', {});
					return $resource(url, {}, {}).get().$promise;
				})
				.then(function (data){
					return new PageSummaryList(data);
				});
		}
		
		return page_summary_list_init;
		
	}));
	
	page_module
	.factory('Page', (['ApiObject'], function(ApiObject){
		function Page(data){
			ApiObject.call(this, data);
		}
		
		Page.prototype = Object.create(ApiObject.prototype);
		
		Page.prototype.render_breadcrumb = function (){
			var breadcrumb_html = '';
			for(var i=0; i<this.breadcrumb.length; i++){
				breadcrumb_html += '<li>';
				
				if (this.breadcrumb[i].permalink === null){
					breadcrumb_html += this.breadcrumb[i].title;
					
				} else {
					breadcrumb_html += 
						'<a href="#/pages/'+this.breadcrumb[i].permalink+'">'+this.breadcrumb[i].title+'</a>';
				}
				
				breadcrumb_html += '</li>';
			}
			
			return '<ul id="breadcrumb">'+breadcrumb_html+'</ul>';
		}
		//--
		
		Page.prototype.constructor = Page;
		
	    return Page;
	}));
	
	page_module
	.factory('page_init', (['api_directory', '$resource', 'Page'], function (api_directory, $resource, Page){
		
		var page_init = function (page_permalink){ 
			
			return api_directory

				.then(function (api_directory){
					
					var url = api_directory
						.get_endpoint_url(
							'cms_restV1_PublicPageAPIView', 
							{
								permalink: page_permalink
							}
						)
					;
					return $resource(url, {}, {}).get().$promise;
				})
				.then(function (data){
					return new Page(data);
				})
			;
		};
		
		return page_init;
		
	}));
	
	page_module
	.factory('HeaderInfo', ([], function(){
		
		var HeaderInfo = {
			scope : null,
			
			setScope : function ($scope){
				this.scope = $scope;
				$scope.metas = undefined;
				$scope.title = undefined;
			},
			
			setMetas : function(metas){
				this.scope.metas = metas;
			},
			
			setTitle : function(title){
				this.scope.title = title;
			}
		}
		
		return HeaderInfo;

	}));

	//------------------------------------------------------------------------------
	//------------------------------------------------------------------------------
	
	page_module
	.directive('ngEnter', function () {
		return {
        	restrict: 'A',
        	link: function (scope, elements, attrs) {
        		elements.bind('keydown keypress', function (event) {
        			if (event.which === 13) {
        				scope.$apply(function () {
        					scope.$eval(attrs.ngEnter);
        				});
        				event.preventDefault();
        			}
        		});
        	}
		};
	});
	
	page_module
	.directive('cmsBindHtml', function(Page, api_directory, $http, $templateCache, $compile){
		
		var htmlBinder = function (scope, element, attrs){
			scope.$watch(attrs.cmsBindHtml, function () {
				var content = scope.$eval(attrs.cmsBindHtml);
				
				if (content) {
					var contentElem = angular.element(content);
					
					$compile(contentElem)(scope);
					
					element.append(contentElem);
				}
            })
			
		}
		
		return {
			link: htmlBinder,
			restrict: 'A',
			
		};
	});
	
	page_module
	.directive('pageBreadcrumb', function (api_directory, $http, $templateCache, $compile){
		return {
			template: '<div data-ng-bind-html="page.render_breadcrumb()"/>',
			restrict: 'AC'
		};
	});
	
	page_module
	.directive('pageMenu', (['Menu', 'api_directory', '$http', '$templateCache', '$compile'],function (Menu, api_directory, $http, $templateCache, $compile){
		
		var pageMenuLinker = function (scope, element, attrs, controller){
						
			api_directory.then(function (api_directory){
				
				var templateUrl   = api_directory.get_endpoint_partial('cms_restV1_MenuAPIView');
				// We load the template menu as a partial manually (directives do not have
				// a partial load system). Using $templateCache we can be sure that the backend
				// is only hit once.
				var templateLoader = $http.get(templateUrl, {cache: $templateCache});
								
				templateLoader.success(function (html) {
					
					// Retrieve the requested menu name from data-page-menu attribute value
					var menuName = attrs.pageMenu;
					
					// Creates an unattached DOM element with the template content.
					var partial = angular.element(html);
											
					/* If a menuName is provided using data-ng-page-menu as an attribute, 
					 * get the menu item from server. Otherwise(as, for example, using 
					 * page-menu in attributes), use the ``item`` element in the current 
					 * scope, most probably to render a sub-menu.  
					 */
					if (menuName){
						// Given a menu name, tries to retrieve the menu instance from server
						var menuUrl  = api_directory
							.get_endpoint_url('cms_restV1_MenuAPIView', {name : menuName});
						
						$http.get(menuUrl).success(function (data){
							
							var menu = new Menu(data);
							
							partial.addClass(attrs.class);
							element.removeClass(attrs.class);
							
							// We can specify a controller for a directive which controls
							// the directive behavior. We are using PagesMenuCtrl to control
							// how the menu interacts with location
							controller.setRootMenu(menu);
							
							// Prepare the scope to be used by the template renderer
							scope.item = menu;
							
							// digest/interpolate scope into the unattached partial
							$compile(partial)(scope);
							
							// attach the partial to the DOM
							element.append(partial);
						}).error(function(data, status, headers, config) {
							scope.item = null;
							scope.menuName = menuName;
							scope.no_pages = true;
							
							$compile(partial)(scope);
							element.append(partial);
						});
					}else{
						// Updates the scope for the recursive call
						scope.item = scope.child_item;
						
						$compile(partial)(scope);
						
						// attach the partial to the DOM
						element.append(partial);
					}
					
	            });
			});
		}
		
		return {
			link      : pageMenuLinker,
			restrict  : 'AC',
			controller: 'PagesMenuCtrl',
			// Setting scope to true we prevent the variables declared in the directive to
			// use the global scope. 
			scope     : true
		};
	}));
	
	//------------------------------------------------------------------------------
	//------------------------------------------------------------------------------
	
	page_module
	.controller('PagesSearchCtrl', (['api_directory','$scope', '$location'], function (api_directory, $scope, $location){
		
		$scope.search = function(query, args){
			
			if(args){
				if(args.prompt){
					query = prompt(django.gettext('Search'));
				}
			}
			
			if(query){
				var trimmedQuery = query.trim();
				
				api_directory
				.then(function (api_directory){
					if(trimmedQuery){
						var url = '/pages/?q='+trimmedQuery;
						$location.url(url);
					}
				});
			}
		};
		
	}));
	
	page_module
	.controller('PagesMenuCtrl', (['$scope', '$location', '$routeParams'], function ($scope, $location, $routeParams){
		
		this.setRootMenu = function (menu){

			$scope.root_menu = menu;
			
			if(!$routeParams.permalink && menu.firstClickableItem && menu.name === "main-menu"){
				$scope.no_pages=false;
				if (!($location.search().q && $location.path() == "/pages/")){
					$location.path('/pages/' + menu.firstClickableItem.permalink);
				}
			}else{
				$scope.no_pages=true;
			}
			
			if($routeParams.permalink){
				$scope.selectedItem = $scope.root_menu.clickables[$routeParams.permalink];
			}
			
			$scope.$on('$routeChangeSuccess', function(next, current) { 
				$scope.selectedItem = $scope.root_menu.clickables[$routeParams.permalink];
			});
		};
	}));
	
	// This controller is still being defined, but not used anymore. Well keep it just in case we need
	// it in the future.
	page_module
	.controller('PageSummaryListCtrl', (['$scope', '$location', 'page_summary_list_init'],function ($scope, $location, page_summary_list_init){
		
		$scope.pages_page = null;
		$scope.is_search  = null;

		var page_summary_list = page_summary_list_init();
		page_summary_list.then(function (page_list){
			$scope.pages_page = page_list;
			$scope.is_search  = false;
			
			if ($location.search().q){
				$scope.page_count = page_list.page_count;
				$scope.keywords   = $location.search().q;
				$scope.is_search  = true;
			}
		});

	}));
	
	page_module
	.controller('PageCtrl', (['$scope', '$routeParams', 'page_init', 'HeaderInfo'],function ($scope, $routeParams, page_init, HeaderInfo){
		
		$scope.page = null;
		
		if($routeParams.permalink){
			var page_init = page_init($routeParams.permalink);
			
			page_init.then(function (page){
				$scope.page = page;
				HeaderInfo.setMetas(page.meta_informations);
				HeaderInfo.setTitle(page.title);
			});	

		}
	}));
	
	
	page_module
	.controller('HeaderController', function ($scope, HeaderInfo){
		HeaderInfo.setScope($scope);
	});
	
})();
