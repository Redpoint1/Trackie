"use strict";

(function () {
	
	var user_module = angular.module('user_priviliged', ['user_common', 'api']);
	
	user_module.run((['api_directory', '$rootScope', '$route'],function(api_directory, $rootScope, $route){
		api_directory.then(function (api_directory) {
			$globalRouteProvider
			// Even using UserCtrl, we have no permalink to load the page. We rely that other
			// element will take care of the situation.
			//.when('/',{ 
			//	redirectTo: '/profile'
			//})
			.when('/profile',{ 
				templateUrl: api_directory.get_endpoint_partial('profile_restV1_UserAPIView'),
				controller : 'ProfileCtrl'                                                        ,
			})
			.when('/logout',{ 
				templateUrl: api_directory.get_endpoint_partial('profile_restV1_LogoutAPIView'),
				controller : 'LogoutCtrl'                                                        ,
			})
			.otherwise({
				redirectTo: '/'
			});
			
			$route.reload();
		});
	}));
	
	//------------------------------------------------------------------------------
	
	user_module
	.factory('loggedin_user', (['CurrentUserInformation', 'UserNotLoggedInException'], function (CurrentUserInformation, UserNotLoggedInException){
		var user;
		
		try{
			user = new CurrentUserInformation();
		}catch(err){
			
			if (err instanceof UserNotLoggedInException)
				CurrentUserInformation.logout();
			
			throw err;
		}
			
		return user;
	}));
	
	//------------------------------------------------------------------------------
	
	user_module
	.controller('ProfileCtrl', (['$scope', 'loggedin_user'], function ($scope, loggedin_user){
		
		loggedin_user.read();
		
		$scope.user            = loggedin_user                     ;
		$scope.error_message   = loggedin_user.last_error_message  ;
		$scope.success_message = loggedin_user.last_success_message;
	}));
	
	user_module
	.controller('LogoutCtrl', (['loggedin_user'], function (loggedin_user){
		loggedin_user.logout();
	}));
	
})();
